import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Users, MapPin, CreditCard } from 'lucide-react';

const BookingSection = () => {
  const [step, setStep] = useState(1);
  const [bookingData, setBookingData] = useState({
    checkIn: '',
    checkOut: '',
    guests: '',
    roomType: '',
    name: '',
    email: '',
    phone: ''
  });

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
  };

  const handlePrev = () => {
    if (step > 1) setStep(step - 1);
  };

  const progressWidth = (step / 3) * 100;

  return (
    <section id="booking" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Book Your Stay
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Reserve your perfect getaway with our simple 3-step booking process.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Progress Indicator */}
          <div className="mb-12 animate-fade-in-up">
            <div className="flex justify-between items-center mb-4">
              {[1, 2, 3].map((stepNum) => (
                <div key={stepNum} className="flex items-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all duration-300 ${
                    step >= stepNum ? 'bg-gold text-white' : 'bg-champagne text-muted-foreground'
                  }`}>
                    {stepNum}
                  </div>
                  <span className={`ml-3 font-medium transition-colors duration-300 ${
                    step >= stepNum ? 'text-gold' : 'text-muted-foreground'
                  }`}>
                    {stepNum === 1 ? 'Dates & Room' : stepNum === 2 ? 'Guest Details' : 'Confirmation'}
                  </span>
                </div>
              ))}
            </div>
            <div className="w-full bg-champagne h-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gold transition-all duration-500 ease-out"
                style={{ width: `${progressWidth}%` }}
              ></div>
            </div>
          </div>

          {/* Booking Form */}
          <div className="card-elegant p-8 animate-scale-in">
            {step === 1 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-6">
                  <Calendar className="w-6 h-6 text-gold" />
                  <h3 className="text-2xl font-playfair font-semibold text-primary">Select Dates & Room</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="checkin" className="text-primary font-medium">Check-in Date</Label>
                    <Input 
                      id="checkin"
                      type="date" 
                      value={bookingData.checkIn}
                      onChange={(e) => setBookingData({...bookingData, checkIn: e.target.value})}
                      className="border-gold/30 focus:border-gold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="checkout" className="text-primary font-medium">Check-out Date</Label>
                    <Input 
                      id="checkout"
                      type="date" 
                      value={bookingData.checkOut}
                      onChange={(e) => setBookingData({...bookingData, checkOut: e.target.value})}
                      className="border-gold/30 focus:border-gold"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-primary font-medium">Number of Guests</Label>
                    <Select value={bookingData.guests} onValueChange={(value) => setBookingData({...bookingData, guests: value})}>
                      <SelectTrigger className="border-gold/30 focus:border-gold">
                        <SelectValue placeholder="Select guests" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Guest</SelectItem>
                        <SelectItem value="2">2 Guests</SelectItem>
                        <SelectItem value="3">3 Guests</SelectItem>
                        <SelectItem value="4">4 Guests</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-primary font-medium">Room Type</Label>
                    <Select value={bookingData.roomType} onValueChange={(value) => setBookingData({...bookingData, roomType: value})}>
                      <SelectTrigger className="border-gold/30 focus:border-gold">
                        <SelectValue placeholder="Select room" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">Standard Suite</SelectItem>
                        <SelectItem value="deluxe">Deluxe Suite</SelectItem>
                        <SelectItem value="premium">Premium Suite</SelectItem>
                        <SelectItem value="presidential">Presidential Suite</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-6">
                  <Users className="w-6 h-6 text-gold" />
                  <h3 className="text-2xl font-playfair font-semibold text-primary">Guest Information</h3>
                </div>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-primary font-medium">Full Name</Label>
                    <Input 
                      id="name"
                      value={bookingData.name}
                      onChange={(e) => setBookingData({...bookingData, name: e.target.value})}
                      placeholder="Enter your full name"
                      className="border-gold/30 focus:border-gold"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-primary font-medium">Email Address</Label>
                    <Input 
                      id="email"
                      type="email"
                      value={bookingData.email}
                      onChange={(e) => setBookingData({...bookingData, email: e.target.value})}
                      placeholder="Enter your email"
                      className="border-gold/30 focus:border-gold"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-primary font-medium">Phone Number</Label>
                  <Input 
                    id="phone"
                    value={bookingData.phone}
                    onChange={(e) => setBookingData({...bookingData, phone: e.target.value})}
                    placeholder="Enter your phone number"
                    className="border-gold/30 focus:border-gold"
                  />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 mb-6">
                  <CreditCard className="w-6 h-6 text-gold" />
                  <h3 className="text-2xl font-playfair font-semibold text-primary">Booking Summary</h3>
                </div>
                
                <div className="bg-champagne/30 p-6 rounded-lg space-y-4">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Check-in:</span>
                    <span className="font-medium text-primary">{bookingData.checkIn}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Check-out:</span>
                    <span className="font-medium text-primary">{bookingData.checkOut}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Guests:</span>
                    <span className="font-medium text-primary">{bookingData.guests}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Room:</span>
                    <span className="font-medium text-primary">{bookingData.roomType}</span>
                  </div>
                  <hr className="border-gold/20" />
                  <div className="flex justify-between text-lg font-semibold">
                    <span className="text-primary">Total:</span>
                    <span className="text-gold">$299/night</span>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8">
              <Button 
                variant="outline" 
                onClick={handlePrev}
                disabled={step === 1}
                className="px-8"
              >
                Previous
              </Button>
              
              {step < 3 ? (
                <Button 
                  variant="gold-glow" 
                  onClick={handleNext}
                  className="px-8"
                >
                  Next Step
                </Button>
              ) : (
                <Button 
                  variant="gold-glow" 
                  className="px-8"
                >
                  Complete Booking
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;