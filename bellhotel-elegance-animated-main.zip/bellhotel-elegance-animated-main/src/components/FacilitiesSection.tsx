import { Waves, Dumbbell, Users, Wifi } from 'lucide-react';
import spaImage from '@/assets/spa-facilities.jpg';
import fitnessImage from '@/assets/fitness-center.jpg';
import conferenceImage from '@/assets/conference-room.jpg';

const FacilitiesSection = () => {
  const facilities = [
    {
      icon: Waves,
      title: "Luxury Spa & Pool",
      description: "Rejuvenate in our world-class spa with infinity pool, treatment rooms, and wellness center.",
      image: spaImage,
      features: ["Infinity Pool", "Massage Therapy", "Sauna & Steam", "Yoga Studio"]
    },
    {
      icon: Dumbbell,
      title: "Fitness Center",
      description: "State-of-the-art equipment and personal training services available 24/7.",
      image: fitnessImage,
      features: ["24/7 Access", "Personal Training", "Modern Equipment", "Group Classes"]
    },
    {
      icon: Users,
      title: "Conference Facilities",
      description: "Professional meeting spaces equipped with cutting-edge technology for business events.",
      image: conferenceImage,
      features: ["Modern AV Systems", "Catering Services", "Business Lounge", "Event Planning"]
    }
  ];

  return (
    <section id="facilities" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Premium Facilities
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover our exceptional amenities designed to enhance your stay 
            with luxury, comfort, and convenience.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {facilities.map((facility, index) => {
            const IconComponent = facility.icon;
            return (
              <div 
                key={facility.title}
                className="group card-elegant hover:shadow-luxe transition-all duration-500 animate-fade-in-up"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="relative overflow-hidden rounded-lg mb-6">
                  <img 
                    src={facility.image} 
                    alt={facility.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 left-4 bg-gold/90 backdrop-blur-sm p-3 rounded-full">
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-2xl font-playfair font-semibold text-primary group-hover:text-gold transition-colors duration-300">
                    {facility.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {facility.description}
                  </p>
                  
                  <ul className="space-y-2">
                    {facility.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3 text-sm text-muted-foreground">
                        <div className="w-1.5 h-1.5 bg-gold rounded-full group-hover:bg-rose-gold transition-colors duration-300"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>

        {/* Additional Amenities */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 animate-fade-in-up">
          {[
            { icon: Wifi, label: "Free Wi-Fi" },
            { icon: Users, label: "Concierge" },
            { icon: Waves, label: "Room Service" },
            { icon: Dumbbell, label: "Valet Parking" }
          ].map((amenity) => {
            const IconComponent = amenity.icon;
            return (
              <div key={amenity.label} className="text-center group">
                <div className="bg-champagne/50 p-4 rounded-full w-16 h-16 mx-auto mb-3 group-hover:bg-gold/20 group-hover:scale-110 transition-all duration-300">
                  <IconComponent className="w-8 h-8 text-primary mx-auto group-hover:text-gold transition-colors duration-300" />
                </div>
                <p className="font-medium text-primary">{amenity.label}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default FacilitiesSection;