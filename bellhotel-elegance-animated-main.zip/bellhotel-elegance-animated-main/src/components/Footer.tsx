import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerSections = [
    {
      title: "Hotel",
      links: [
        { label: "About Us", href: "#about" },
        { label: "Rooms & Suites", href: "#rooms" },
        { label: "Dining", href: "#dining" },
        { label: "Spa & Wellness", href: "#spa" },
        { label: "Events", href: "#events" }
      ]
    },
    {
      title: "Services",
      links: [
        { label: "Concierge", href: "#concierge" },
        { label: "Business Center", href: "#business" },
        { label: "Valet Parking", href: "#parking" },
        { label: "Airport Transfer", href: "#transfer" },
        { label: "Pet Services", href: "#pets" }
      ]
    },
    {
      title: "Policies",
      links: [
        { label: "Privacy Policy", href: "#privacy" },
        { label: "Terms & Conditions", href: "#terms" },
        { label: "Cancellation", href: "#cancellation" },
        { label: "Accessibility", href: "#accessibility" }
      ]
    }
  ];

  return (
    <footer className="bg-navy text-white relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-animated opacity-10"></div>
      
      <div className="relative z-10">
        {/* Newsletter Section */}
        <div className="border-b border-white/10">
          <div className="container mx-auto px-6 py-16">
            <div className="max-w-2xl mx-auto text-center">
              <h3 className="text-3xl font-playfair font-bold mb-4">
                Stay Updated with Our <span className="text-secondary">Exclusive Offers</span>
              </h3>
              <p className="text-champagne/80 mb-8">
                Subscribe to receive special rates, seasonal packages, and luxury travel insights.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <Input 
                  type="email" 
                  placeholder="Enter your email address"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:border-secondary"
                />
                <Button variant="hero" className="whitespace-nowrap">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Footer Content */}
        <div className="container mx-auto px-6 py-16">
          <div className="grid lg:grid-cols-5 gap-8">
            {/* Hotel Info */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h2 className="text-3xl font-playfair font-bold text-secondary mb-4">
                  The Bell Hotel
                </h2>
                <p className="text-champagne/80 leading-relaxed mb-6">
                  Where comfort meets elegance. Experience luxury hospitality that has been 
                  refined over a century of exceptional service and attention to detail.
                </p>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-3 text-champagne/80">
                  <div className="w-5 h-5 border border-secondary rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                  </div>
                  <span>123 Luxury Boulevard, Metropolitan City, MC 12345</span>
                </div>
                <div className="flex items-center gap-3 text-champagne/80">
                  <div className="w-5 h-5 border border-secondary rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                  </div>
                  <span>+1 (555) 123-BELL</span>
                </div>
                <div className="flex items-center gap-3 text-champagne/80">
                  <div className="w-5 h-5 border border-secondary rounded-full flex items-center justify-center flex-shrink-0">
                    <div className="w-2 h-2 bg-secondary rounded-full"></div>
                  </div>
                  <span>reservations@thebellhotel.com</span>
                </div>
              </div>

              {/* Social Media */}
              <div className="flex gap-4 pt-4">
                {['Facebook', 'Instagram', 'Twitter', 'LinkedIn'].map((social) => (
                  <div 
                    key={social}
                    className="w-10 h-10 border border-white/20 rounded-full flex items-center justify-center hover:border-secondary hover:bg-secondary/10 transition-all duration-300 cursor-pointer group"
                  >
                    <span className="text-xs group-hover:text-secondary transition-colors duration-300">
                      {social[0]}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Links */}
            {footerSections.map((section) => (
              <div key={section.title}>
                <h4 className="text-lg font-playfair font-semibold text-secondary mb-6">
                  {section.title}
                </h4>
                <ul className="space-y-3">
                  {section.links.map((link) => (
                    <li key={link.label}>
                      <a 
                        href={link.href}
                        className="text-champagne/80 hover:text-secondary transition-colors duration-300 text-sm"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10">
          <div className="container mx-auto px-6 py-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-champagne/60 text-sm">
                © {currentYear} The Bell Hotel. All rights reserved.
              </p>
              <div className="flex gap-6 text-sm">
                <a href="#privacy" className="text-champagne/60 hover:text-secondary transition-colors duration-300">
                  Privacy Policy
                </a>
                <a href="#terms" className="text-champagne/60 hover:text-secondary transition-colors duration-300">
                  Terms of Service
                </a>
                <a href="#cookies" className="text-champagne/60 hover:text-secondary transition-colors duration-300">
                  Cookie Policy
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;