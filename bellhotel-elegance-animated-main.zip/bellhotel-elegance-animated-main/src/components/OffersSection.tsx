import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Heart, Sparkles, Gift } from 'lucide-react';

const OffersSection = () => {
  const offers = [
    {
      icon: Heart,
      title: "Romantic Getaway",
      description: "Perfect for couples seeking a romantic escape with champagne, rose petals, and spa treatments.",
      discount: "25% OFF",
      price: "From $199/night",
      features: ["Champagne on arrival", "Couples spa treatment", "Private dinner", "Late checkout"],
      bgClass: "bg-rose-gold/10 hover:bg-rose-gold/20",
      iconColor: "text-rose-gold"
    },
    {
      icon: Sparkles,
      title: "Luxury Weekend",
      description: "Indulge in ultimate luxury with premium amenities and exclusive access to our facilities.",
      discount: "30% OFF",
      price: "From $299/night",
      features: ["Suite upgrade", "Spa access", "Premium dining", "Personal concierge"],
      bgClass: "bg-gold/10 hover:bg-gold/20",
      iconColor: "text-gold"
    },
    {
      icon: Gift,
      title: "Special Occasions",
      description: "Celebrate birthdays, anniversaries, or achievements with our tailored celebration package.",
      discount: "20% OFF",
      price: "From $249/night",
      features: ["Custom decorations", "Celebration cake", "Photography session", "Memory package"],
      bgClass: "bg-primary/10 hover:bg-primary/20",
      iconColor: "text-primary"
    }
  ];

  return (
    <section id="offers" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Special Offers
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover our exclusive packages designed to make your stay even more memorable 
            with exceptional value and unique experiences.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {offers.map((offer, index) => {
            const IconComponent = offer.icon;
            return (
              <div 
                key={offer.title}
                className={`group relative p-8 rounded-xl transition-all duration-500 animate-fade-in-up border border-gold/20 hover:border-gold/40 ${offer.bgClass}`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="absolute top-4 right-4">
                  <Badge className="bg-gold text-white font-semibold px-3 py-1">
                    {offer.discount}
                  </Badge>
                </div>

                <div className="mb-6">
                  <div className={`inline-flex p-3 rounded-full ${offer.bgClass} mb-4`}>
                    <IconComponent className={`w-8 h-8 ${offer.iconColor}`} />
                  </div>
                  <h3 className="text-2xl font-playfair font-semibold text-primary mb-3">
                    {offer.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-4">
                    {offer.description}
                  </p>
                  <div className="text-2xl font-bold text-gold mb-6">
                    {offer.price}
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  {offer.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-sm text-muted-foreground">
                      <div className={`w-2 h-2 rounded-full ${offer.iconColor.replace('text-', 'bg-')}`}></div>
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-gold group-hover:text-white group-hover:border-gold transition-all duration-300"
                >
                  Book This Offer
                </Button>
              </div>
            );
          })}
        </div>

        {/* Seasonal Banner */}
        <div className="bg-gradient-primary p-8 rounded-xl text-center animate-fade-in-up">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Calendar className="w-6 h-6 text-white" />
            <h3 className="text-2xl font-playfair font-semibold text-white">
              Limited Time Offer
            </h3>
          </div>
          <p className="text-white/90 text-lg mb-6 max-w-2xl mx-auto">
            Book your stay for the holiday season and enjoy exclusive perks including 
            complimentary breakfast, spa credits, and priority reservations.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button variant="secondary" className="px-8 py-3 bg-white text-primary hover:bg-champagne">
              View Details
            </Button>
            <span className="text-white/80 text-sm">Valid until December 31st</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OffersSection;