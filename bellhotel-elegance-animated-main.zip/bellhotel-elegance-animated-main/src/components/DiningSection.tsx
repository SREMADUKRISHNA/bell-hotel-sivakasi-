import { Button } from '@/components/ui/button';
import restaurantImage from '@/assets/restaurant-interior.jpg';
import elegantRestaurant from '@/assets/elegant-restaurant.jpg';

const DiningSection = () => {
  return (
    <section id="dining" className="py-20 bg-gradient-elegant">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Culinary Excellence
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Indulge in our award-winning restaurant where world-class chefs create 
            extraordinary dining experiences with locally sourced ingredients.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in-up">
            <div className="space-y-6">
              <h3 className="text-2xl font-playfair font-semibold text-primary">
                The Bell Restaurant
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                Experience fine dining at its finest with our Michelin-trained chefs who craft 
                seasonal menus using the freshest local ingredients. Our sommelier-curated wine 
                collection perfectly complements every dish.
              </p>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  Breakfast: 7:00 AM - 11:00 AM
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  Lunch: 12:00 PM - 3:00 PM
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-gold rounded-full"></div>
                  Dinner: 6:00 PM - 11:00 PM
                </li>
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button variant="elegant" className="px-8 py-3">
                View Menu
              </Button>
              <Button variant="outline" className="px-8 py-3">
                Make Reservation
              </Button>
            </div>
          </div>

          <div className="relative animate-scale-in">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="overflow-hidden rounded-lg card-elegant hover:scale-105 transition-transform duration-300">
                  <img 
                    src={restaurantImage} 
                    alt="Elegant restaurant interior with fine dining setup"
                    className="w-full h-48 object-cover"
                  />
                </div>
                <div className="bg-gold/10 p-6 rounded-lg">
                  <h4 className="font-playfair font-semibold text-primary mb-2">Wine Cellar</h4>
                  <p className="text-sm text-muted-foreground">Over 500 premium wines from around the world</p>
                </div>
              </div>
              
              <div className="space-y-4 mt-8">
                <div className="bg-rose-gold/10 p-6 rounded-lg">
                  <h4 className="font-playfair font-semibold text-primary mb-2">Private Dining</h4>
                  <p className="text-sm text-muted-foreground">Intimate dining rooms for special occasions</p>
                </div>
                <div className="overflow-hidden rounded-lg card-elegant hover:scale-105 transition-transform duration-300">
                  <img 
                    src={elegantRestaurant} 
                    alt="Fine dining dishes and elegant table setting"
                    className="w-full h-48 object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DiningSection;