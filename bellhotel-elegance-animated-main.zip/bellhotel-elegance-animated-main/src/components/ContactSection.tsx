import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import elegantRestaurant from '@/assets/elegant-restaurant.jpg';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission logic here
    console.log('Form submitted:', formData);
  };

  return (
    <section id="contact" className="py-20 bg-gradient-elegant">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="text-secondary font-medium tracking-wide uppercase text-sm mb-2">Get in Touch</p>
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-6">
            Contact <span className="text-secondary">Our Team</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our dedicated concierge team is available 24/7 to assist with reservations, 
            special requests, and any inquiries about your stay.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Contact Form */}
          <div className="card-elegant">
            <h3 className="text-2xl font-playfair font-bold text-primary mb-6">Send us a Message</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-medium text-foreground">Full Name *</label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="focus:ring-secondary focus:border-secondary"
                    placeholder="Your full name"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-medium text-foreground">Email Address *</label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="focus:ring-secondary focus:border-secondary"
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-medium text-foreground">Phone Number</label>
                  <Input
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="focus:ring-secondary focus:border-secondary"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium text-foreground">Subject *</label>
                  <Input
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    className="focus:ring-secondary focus:border-secondary"
                    placeholder="How can we help you?"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium text-foreground">Message *</label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={5}
                  className="focus:ring-secondary focus:border-secondary resize-none"
                  placeholder="Please share your message or inquiry..."
                />
              </div>

              <Button type="submit" variant="hero" className="w-full text-lg py-3">
                Send Message
              </Button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            {/* Image */}
            <div className="relative overflow-hidden rounded-2xl shadow-luxe">
              <img 
                src={elegantRestaurant} 
                alt="Elegant hotel restaurant interior with warm lighting" 
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/40 to-transparent"></div>
            </div>

            {/* Contact Info Cards */}
            <div className="space-y-6">
              <div className="card-elegant">
                <h4 className="text-xl font-playfair font-bold text-primary mb-4">Hotel Information</h4>
                <div className="space-y-3 text-muted-foreground">
                  <div className="flex items-start gap-3">
                    <div className="w-5 h-5 border border-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Address</p>
                      <p>123 Luxury Boulevard<br />Metropolitan City, MC 12345</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-5 h-5 border border-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Phone</p>
                      <p>+1 (555) 123-BELL</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-5 h-5 border border-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <div className="w-2 h-2 bg-secondary rounded-full"></div>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Email</p>
                      <p>reservations@thebellhotel.com</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card-elegant">
                <h4 className="text-xl font-playfair font-bold text-primary mb-4">Business Hours</h4>
                <div className="space-y-2 text-muted-foreground">
                  <div className="flex justify-between">
                    <span>Front Desk</span>
                    <span className="text-foreground">24/7</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Concierge</span>
                    <span className="text-foreground">24/7</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Restaurant</span>
                    <span className="text-foreground">6:00 AM - 11:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Spa</span>
                    <span className="text-foreground">8:00 AM - 10:00 PM</span>
                  </div>
                </div>
              </div>

              <div className="card-elegant">
                <h4 className="text-xl font-playfair font-bold text-primary mb-4">Quick Actions</h4>
                <div className="space-y-3">
                  <Button variant="elegant" className="w-full">
                    Make a Reservation
                  </Button>
                  <Button variant="outline" className="w-full border-secondary text-secondary hover:bg-secondary/10">
                    Request Information
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;