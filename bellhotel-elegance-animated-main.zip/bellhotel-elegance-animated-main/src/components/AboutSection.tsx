import { useEffect, useRef, useState } from 'react';
import luxurySuite from '@/assets/luxury-suite.jpg';

const AboutSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} className="py-20 bg-gradient-elegant">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className={`space-y-6 ${isVisible ? 'animate-fade-in-up' : 'opacity-0'}`}>
            <div className="space-y-2">
              <p className="text-secondary font-medium tracking-wide uppercase text-sm">About Us</p>
              <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary leading-tight">
                A Legacy of 
                <span className="text-secondary"> Luxury</span>
              </h2>
            </div>
            
            <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
              <p>
                Since 1923, The Bell Hotel has been synonymous with refined elegance and 
                exceptional hospitality. Nestled in the heart of the city, our boutique 
                hotel offers an intimate luxury experience that combines timeless charm 
                with modern sophistication.
              </p>
              
              <p>
                Every guest room and suite is meticulously designed with bespoke furnishings, 
                premium amenities, and thoughtful touches that reflect our commitment to 
                creating extraordinary experiences. From our award-winning restaurant to 
                our tranquil spa, every moment at The Bell Hotel is crafted to perfection.
              </p>
              
              <p className="text-primary font-medium">
                "We don't just provide accommodation; we create memories that last a lifetime."
              </p>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-6">
              <div className="text-center">
                <div className="text-3xl font-playfair font-bold text-secondary mb-2">100+</div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">Years of Excellence</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-playfair font-bold text-secondary mb-2">5★</div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">Luxury Rating</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-playfair font-bold text-secondary mb-2">24/7</div>
                <div className="text-sm text-muted-foreground uppercase tracking-wide">Concierge Service</div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className={`relative ${isVisible ? 'animate-scale-in' : 'opacity-0'}`}>
            <div className="relative overflow-hidden rounded-2xl shadow-luxe">
              <img 
                src={luxurySuite} 
                alt="Luxurious hotel suite interior with elegant decor" 
                className="w-full h-96 lg:h-[500px] object-cover hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/20 to-transparent"></div>
            </div>
            
            {/* Floating Badge */}
            <div className="absolute -bottom-6 -left-6 glass-effect rounded-xl p-6 shadow-luxe">
              <div className="text-center">
                <div className="text-2xl font-playfair font-bold text-secondary mb-1">Est.</div>
                <div className="text-3xl font-playfair font-bold text-primary">1923</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;