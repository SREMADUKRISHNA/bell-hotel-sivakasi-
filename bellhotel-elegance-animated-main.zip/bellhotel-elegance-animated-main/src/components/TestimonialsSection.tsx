import { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';

const TestimonialsSection = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonials = [
    {
      name: "Sarah & Michael Johnson",
      location: "New York, USA",
      rating: 5,
      text: "Our romantic getaway at The Bell Hotel exceeded all expectations. The attention to detail, from the champagne upon arrival to the breathtaking sunset views, made our anniversary truly unforgettable.",
      image: "👩‍🦰👨‍🦱"
    },
    {
      name: "Emma Wilson",
      location: "London, UK",
      rating: 5,
      text: "The luxury and elegance of The Bell Hotel is unmatched. The spa facilities are world-class, and the dining experience was absolutely phenomenal. I've already booked my next stay!",
      image: "👩‍🦳"
    },
    {
      name: "David & Lisa Chen",
      location: "Toronto, Canada",
      rating: 5,
      text: "From the moment we arrived, we were treated like royalty. The staff's professionalism and the hotel's stunning architecture created the perfect atmosphere for our business retreat.",
      image: "👨‍💼👩‍💼"
    },
    {
      name: "James Rodriguez",
      location: "Madrid, Spain",
      rating: 5,
      text: "The Bell Hotel redefined luxury for me. Every detail, from the Egyptian cotton sheets to the personalized concierge service, showcased their commitment to excellence.",
      image: "👨‍🦱"
    }
  ];

  // Auto-slide functionality
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [testimonials.length]);

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="py-20 bg-gradient-elegant">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Guest Testimonials
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Discover what our guests say about their extraordinary experiences 
            at The Bell Hotel.
          </p>
        </div>

        <div className="max-w-4xl mx-auto relative">
          {/* Main Testimonial Display */}
          <div className="card-elegant p-12 text-center animate-fade-in-up">
            <div className="mb-8">
              <Quote className="w-12 h-12 text-gold mx-auto mb-6 opacity-50" />
              <p className="text-xl leading-relaxed text-muted-foreground mb-8 italic">
                "{testimonials[currentTestimonial].text}"
              </p>
              
              {/* Star Rating */}
              <div className="flex justify-center gap-1 mb-6">
                {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-gold text-gold" />
                ))}
              </div>
              
              {/* Guest Info */}
              <div className="flex items-center justify-center gap-4">
                <div className="text-4xl">{testimonials[currentTestimonial].image}</div>
                <div className="text-left">
                  <h4 className="font-playfair font-semibold text-primary text-lg">
                    {testimonials[currentTestimonial].name}
                  </h4>
                  <p className="text-muted-foreground text-sm">
                    {testimonials[currentTestimonial].location}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <div className="flex justify-center gap-4 mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={prevTestimonial}
              className="rounded-full border-gold/30 hover:bg-gold hover:text-white transition-all duration-300"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={nextTestimonial}
              className="rounded-full border-gold/30 hover:bg-gold hover:text-white transition-all duration-300"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center gap-2 mt-6">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentTestimonial(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentTestimonial ? 'bg-gold' : 'bg-gold/30 hover:bg-gold/50'
                }`}
              />
            ))}
          </div>
        </div>

        {/* Review Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16 animate-fade-in-up">
          {[
            { number: "4.9", label: "Average Rating" },
            { number: "2,500+", label: "Happy Guests" },
            { number: "98%", label: "Return Rate" },
            { number: "24/7", label: "Guest Support" }
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl font-bold text-gold mb-2">{stat.number}</div>
              <div className="text-muted-foreground font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;