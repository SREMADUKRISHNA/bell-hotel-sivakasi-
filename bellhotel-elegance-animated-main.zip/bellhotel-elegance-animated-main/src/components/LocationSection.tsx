import { Button } from '@/components/ui/button';
import { MapPin, Clock, Camera, Navigation } from 'lucide-react';

const LocationSection = () => {
  const attractions = [
    {
      name: "Historic Downtown",
      distance: "0.3 miles",
      description: "Explore charming cobblestone streets, boutique shops, and local cafes.",
      image: "🏛️"
    },
    {
      name: "Riverside Park",
      distance: "0.5 miles", 
      description: "Beautiful waterfront park perfect for morning walks and sunset views.",
      image: "🌳"
    },
    {
      name: "Art Museum",
      distance: "0.8 miles",
      description: "World-class art collection featuring both classical and contemporary works.",
      image: "🎨"
    },
    {
      name: "Shopping District",
      distance: "1.2 miles",
      description: "Premium shopping with designer boutiques and luxury brands.",
      image: "🛍️"
    }
  ];

  return (
    <section id="location" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Prime Location
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Perfectly positioned in the heart of the city, The Bell Hotel offers 
            easy access to the finest attractions, dining, and cultural experiences.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Map Placeholder */}
          <div className="animate-scale-in">
            <div className="bg-champagne/30 rounded-xl p-8 h-96 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-gold/20 to-navy/20"></div>
              <div className="relative z-10 h-full flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-16 h-16 text-gold mx-auto mb-4" />
                  <h3 className="text-2xl font-playfair font-semibold text-primary mb-2">
                    The Bell Hotel
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    123 Luxury Avenue<br />
                    Downtown District<br />
                    City Center, 12345
                  </p>
                  <Button variant="gold-glow" className="px-6">
                    <Navigation className="w-4 h-4 mr-2" />
                    Get Directions
                  </Button>
                </div>
              </div>
              
              {/* Animated location markers */}
              <div className="absolute top-20 left-16 w-4 h-4 bg-rose-gold rounded-full animate-pulse"></div>
              <div className="absolute bottom-24 right-20 w-3 h-3 bg-gold rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
              <div className="absolute top-32 right-16 w-3 h-3 bg-primary rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
            </div>
          </div>

          {/* Nearby Attractions */}
          <div className="space-y-6 animate-fade-in-up">
            <div className="mb-8">
              <h3 className="text-2xl font-playfair font-semibold text-primary mb-4">
                Nearby Attractions
              </h3>
              <p className="text-muted-foreground">
                Discover the best of the city within walking distance from our hotel.
              </p>
            </div>

            <div className="space-y-4">
              {attractions.map((attraction, index) => (
                <div 
                  key={attraction.name}
                  className="group bg-card rounded-lg p-6 border border-gold/20 hover:border-gold/40 hover:shadow-elegant transition-all duration-300"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex items-start gap-4">
                    <div className="text-3xl">{attraction.image}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-playfair font-semibold text-primary group-hover:text-gold transition-colors duration-300">
                          {attraction.name}
                        </h4>
                        <span className="text-sm text-muted-foreground bg-champagne/50 px-2 py-1 rounded">
                          {attraction.distance}
                        </span>
                      </div>
                      <p className="text-muted-foreground text-sm">
                        {attraction.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Additional Info */}
            <div className="bg-gold/10 rounded-lg p-6 mt-8">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="w-5 h-5 text-gold" />
                <h4 className="font-playfair font-semibold text-primary">Transportation</h4>
              </div>
              <div className="space-y-2 text-sm text-muted-foreground">
                <div className="flex justify-between">
                  <span>Airport Shuttle:</span>
                  <span className="font-medium">Complimentary (30 min)</span>
                </div>
                <div className="flex justify-between">
                  <span>Taxi to Downtown:</span>
                  <span className="font-medium">5 minutes</span>
                </div>
                <div className="flex justify-between">
                  <span>Metro Station:</span>
                  <span className="font-medium">2 blocks away</span>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <Button variant="elegant" className="flex-1">
                <Camera className="w-4 h-4 mr-2" />
                Virtual Tour
              </Button>
              <Button variant="outline" className="flex-1">
                Download Map
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LocationSection;