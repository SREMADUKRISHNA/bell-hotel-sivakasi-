import { Button } from '@/components/ui/button';
import heroImage from '@/assets/hero-hotel-exterior.jpg';

const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img 
          src={heroImage} 
          alt="The Bell Hotel exterior at dusk with elegant lighting" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy/70 via-navy/40 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-animated opacity-20"></div>
      </div>

      {/* Hero Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <div className="animate-fade-in-up">
          <h1 className="text-5xl md:text-7xl font-playfair font-bold text-white mb-6 leading-tight">
            The Bell Hotel
          </h1>
          
          <p className="text-xl md:text-2xl text-champagne mb-2 font-light">
            Where Comfort Meets Elegance
          </p>
          
          <p className="text-lg text-champagne/90 mb-12 max-w-2xl mx-auto leading-relaxed">
            Experience luxury and sophistication in our carefully curated accommodations, 
            where every detail is designed to create unforgettable memories.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button variant="gold-glow" className="text-lg px-10 py-4">
              Book Your Stay
            </Button>
            <Button variant="outline" className="text-white border-white hover:bg-white/10 text-lg px-8 py-4">
              Virtual Tour
            </Button>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/50 rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 border border-gold/30 rounded-full animate-pulse hidden lg:block"></div>
      <div className="absolute bottom-20 right-10 w-16 h-16 border border-rose-gold/30 rounded-full animate-pulse hidden lg:block"></div>
    </section>
  );
};

export default HeroSection;