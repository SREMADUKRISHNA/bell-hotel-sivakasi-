import { Button } from '@/components/ui/button';
import luxurySuite from '@/assets/luxury-suite.jpg';

const RoomsSection = () => {
  const rooms = [
    {
      id: 1,
      name: "Luxury Suite",
      type: "Presidential Suite",
      size: "850 sq ft",
      guests: "2-4 guests",
      price: "$850",
      image: luxurySuite,
      features: ["Ocean View", "Private Balcony", "Jacuzzi", "Butler Service"],
      description: "Our flagship suite offering unparalleled luxury with panoramic views and premium amenities."
    },
    {
      id: 2,
      name: "Executive Room",
      type: "Business Class",
      size: "450 sq ft", 
      guests: "1-2 guests",
      price: "$420",
      image: luxurySuite,
      features: ["City View", "Work Desk", "Premium WiFi", "Express Checkout"],
      description: "Perfect for business travelers seeking comfort and functionality in an elegant setting."
    },
    {
      id: 3,
      name: "Romantic Getaway",
      type: "Honeymoon Suite", 
      size: "650 sq ft",
      guests: "2 guests",
      price: "$680",
      image: luxurySuite,
      features: ["Rose Petals", "Champagne", "Fireplace", "Couples Spa"],
      description: "An intimate retreat designed for romance with luxurious touches and personalized service."
    }
  ];

  return (
    <section id="rooms" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="text-secondary font-medium tracking-wide uppercase text-sm mb-2">Accommodations</p>
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-6">
            Luxury <span className="text-secondary">Rooms & Suites</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Each room is a sanctuary of comfort and elegance, thoughtfully designed to provide 
            an exceptional experience for our distinguished guests.
          </p>
        </div>

        {/* Rooms Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {rooms.map((room, index) => (
            <div 
              key={room.id} 
              className="card-elegant group cursor-pointer"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              {/* Room Image */}
              <div className="relative overflow-hidden rounded-lg mb-6">
                <img 
                  src={room.image} 
                  alt={`${room.name} - ${room.description}`}
                  className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                {/* Price Badge */}
                <div className="absolute top-4 right-4 bg-secondary text-secondary-foreground px-3 py-1 rounded-full font-medium">
                  {room.price}/night
                </div>
              </div>

              {/* Room Details */}
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-secondary font-medium uppercase tracking-wide">{room.type}</p>
                  <h3 className="text-2xl font-playfair font-bold text-primary mb-2">{room.name}</h3>
                  <p className="text-muted-foreground text-sm">{room.description}</p>
                </div>

                {/* Room Info */}
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>{room.size}</span>
                  <span>{room.guests}</span>
                </div>

                {/* Features */}
                <div className="flex flex-wrap gap-2">
                  {room.features.map((feature, idx) => (
                    <span 
                      key={idx}
                      className="text-xs bg-muted text-muted-foreground px-2 py-1 rounded-full"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                {/* CTA Button */}
                <Button variant="elegant" className="w-full group-hover:bg-secondary group-hover:text-secondary-foreground transition-all duration-300">
                  View Details
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* View All Rooms CTA */}
        <div className="text-center mt-12">
          <Button variant="hero" className="text-lg px-8 py-4">
            View All Accommodations
          </Button>
        </div>
      </div>
    </section>
  );
};

export default RoomsSection;