import { useState } from 'react';
import { X } from 'lucide-react';
import heroImage from '@/assets/hero-hotel-exterior.jpg';
import luxurySuite from '@/assets/luxury-suite.jpg';
import restaurantImage from '@/assets/restaurant-interior.jpg';
import spaImage from '@/assets/spa-facilities.jpg';
import fitnessImage from '@/assets/fitness-center.jpg';
import conferenceImage from '@/assets/conference-room.jpg';

const GallerySection = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryImages = [
    { src: heroImage, alt: "Hotel exterior at dusk", category: "Exterior" },
    { src: luxurySuite, alt: "Luxury suite interior", category: "Rooms" },
    { src: restaurantImage, alt: "Restaurant interior", category: "Dining" },
    { src: spaImage, alt: "Spa and wellness center", category: "Facilities" },
    { src: fitnessImage, alt: "Modern fitness center", category: "Facilities" },
    { src: conferenceImage, alt: "Conference room", category: "Business" }
  ];

  return (
    <section id="gallery" className="py-20 bg-gradient-elegant">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl md:text-5xl font-playfair font-bold text-primary mb-4">
            Gallery
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Take a visual journey through our luxurious spaces and discover 
            the elegance that awaits you at The Bell Hotel.
          </p>
        </div>

        {/* Masonry Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {galleryImages.map((image, index) => (
            <div 
              key={index}
              className={`group relative overflow-hidden rounded-lg cursor-pointer animate-scale-in ${
                index === 0 ? 'md:col-span-2 md:row-span-2' : 
                index === 3 ? 'lg:row-span-2' : ''
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
              onClick={() => setSelectedImage(image.src)}
            >
              <img 
                src={image.src} 
                alt={image.alt}
                className={`w-full object-cover group-hover:scale-110 transition-transform duration-500 ${
                  index === 0 ? 'h-96 md:h-full' : 'h-64'
                }`}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="absolute bottom-4 left-4 right-4 transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                <span className="inline-block bg-gold/90 text-white px-3 py-1 rounded-full text-sm font-medium mb-2">
                  {image.category}
                </span>
                <p className="text-white font-medium">{image.alt}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Lightbox Modal */}
        {selectedImage && (
          <div 
            className="fixed inset-0 bg-navy/90 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in-up"
            onClick={() => setSelectedImage(null)}
          >
            <div className="relative max-w-4xl max-h-full">
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute -top-12 right-0 text-white hover:text-gold transition-colors duration-300"
              >
                <X className="w-8 h-8" />
              </button>
              <img 
                src={selectedImage} 
                alt="Gallery image"
                className="max-w-full max-h-full object-contain rounded-lg shadow-luxe animate-scale-in"
                onClick={(e) => e.stopPropagation()}
              />
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default GallerySection;